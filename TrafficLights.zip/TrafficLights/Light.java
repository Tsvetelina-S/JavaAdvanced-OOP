package Abstraction.TrafficLights;

public enum Light {
    RED,GREEN,YELLOW;

    public static Light parse(String s){
        return Light.valueOf(s);
    }
}
